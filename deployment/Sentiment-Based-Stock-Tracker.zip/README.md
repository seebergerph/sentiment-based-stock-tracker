# Sentiment-Based-Stock-Tracker
This repository represents the practical problem-solving project for the course COSC2640 Cloud Computing.
