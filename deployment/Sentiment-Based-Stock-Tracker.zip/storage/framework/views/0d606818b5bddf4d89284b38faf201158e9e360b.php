<?php $__env->startSection('content'); ?>
    <div class="container px-5">
        <div class="d-flex justify-content-between">
            <div>
                <h1 class="page-header" style="margin: 0 !important;"><?php echo e($data['quote']['name'] ?? 'Undefined'); ?> (<?php echo e($data['stock']->symbol); ?>)</h1>
                <p style="font-size: 12px;">Currency in USD</p>
            </div>
            <?php echo Form::open(['action' => ['StocksController@destroy', $data['stock']->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        </div>

        <div>
            <p style="font-size: 12px; margin: 0 !important;">At close</p>
            <div class="d-flex">
                <div>
                    <span class="font-weight-bold" style="font-size: 24px;"><?php echo e($data['quote']['close']); ?></span>
                    <span class="ml-1" style="font-size: 14px;"><?php echo e($data['quote']['change']); ?></span>
                    <span style="font-size: 14px;">(<?php echo e($data['quote']['percent_change']); ?>%)</span>
                </div>
                <div class="ml-4">
                    <span style="font-size: 24px;"><?php echo e($data['quote']['average_volume']); ?></span>
                    <span style="font-size: 14px;">Volume</span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div id="chart">
                </div>
            </div>
        </div>

        <div class="mt-4">

            <div class="d-flex justify-content-between">
                <div>
                    <span class="font-weight-bold" style="font-size: 24px;"><?php echo e($data['sentiment']['countTweets'] ?? '?'); ?></span>
                    <span style="font-size: 14px;">Tweets</span>
                    <span class="ml-2" style="font-size: 14px;">(Last <?php echo e($data['tweet_period']); ?> days)</span>
                </div>
                <a class="btn btn-secondary" href="/Sentiment-Based-Stock-Tracker/public/stocks/<?php echo e($data['stock']->id); ?>/sentiment">
                    Details
                </a>
            </div>
        </div>

        <div class="row mt-3 mb-2">
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <span style="font-size: 24px;"><?php echo e($data['sentiment']['averagePos'] ?? '?'); ?>%</span>
                        <span>Positive</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card text-white bg-danger">
                    <div class="card-body">
                        <span style="font-size: 24px;"><?php echo e($data['sentiment']['averageNeg'] ?? '?'); ?>%</span>
                        <span>Negative</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <span style="font-size: 24px;"><?php echo e($data['sentiment']['averageNeu'] ?? '?'); ?>%</span>
                        <span>Neutral</span>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <span style="font-size: 24px"><?php echo e($data['sentiment']['averageMix'] ?? '?'); ?>%</span>
                        <span>Mixed</span>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="application/javascript" src="<?php echo e(asset('js/responsivefy.js')); ?>"></script>
    <script type="application/javascript" src="<?php echo e(asset('js/chart.js')); ?>"></script>
    <script type="application/javascript">
        margin = {top: 10, right: 50, bottom: 30, left: 20};
        width = 1000;
        height= 400;
        intraday = false;
        data = <?php echo $data['series']; ?>['values'];
        chart = new StockChart("chart", margin, width, height, intraday, data);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sentiment-Based-Stock-Tracker\resources\views/stocks/show.blade.php ENDPATH**/ ?>