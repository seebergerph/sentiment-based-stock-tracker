

<?php $__env->startSection('content'); ?>
<div class="container px-5">
    <?php echo Form::open(['action' => 'SettingsController@update', 'method' => 'POST']); ?>

        <div class="d-flex justify-content-between">
            <h1 class="page-header">Settings</h1> 
            <button type="submit" class="btn btn-success">
                Save
            </button>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-6">
                    <?php echo e(Form::label('tweet_period', 'Period (days)')); ?>

                    <?php echo e(Form::input('number', 'tweet_period', $config['tweet_period'], ['class' => 'form-control', 
                                                                                      'min' => 1])); ?>

                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-6">
                    <?php echo e(Form::label('tweet_limit', 'Tweet Limit (amount)')); ?>

                    <?php echo e(Form::input('number', 'tweet_limit', $config['tweet_limit'], ['class' => 'form-control', 
                                                                                    'min' => 100])); ?>

                </div>
            </div>
        </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sentiment-Based-Stock-Tracker\resources\views/settings.blade.php ENDPATH**/ ?>