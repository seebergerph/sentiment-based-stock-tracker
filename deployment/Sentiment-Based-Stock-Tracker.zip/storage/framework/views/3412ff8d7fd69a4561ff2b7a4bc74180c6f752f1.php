

<?php $__env->startSection('content'); ?>
    <div class="container px-5">
        <?php echo Form::open(['action' => 'StocksController@store', 'method' => 'POST']); ?>

            <div class="d-flex justify-content-between">
                <h1 class="page-header">Add Stock</h1> 
                <button type="submit" class="btn btn-success">
                    Save
                </button>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-6">
                        <?php echo e(Form::label('symbol', 'Symbol')); ?>

                        <?php echo e(Form::text('symbol', '', ['class' => 'form-control', 
                                                    'placeholder' => 'Ticker Symbol'])); ?>

                    </div>
                </div>
            </div>
            <div class="form-group">
                <button id="add-topic" type="button" class="btn btn-primary">
                    Add Topic
                </button>
            </div>
            <div class="form-group">
                <?php echo e(Form::label('topics', 'Twitter-Topics')); ?>

                <table name="topics" class="table">
                    <tbody>
                    </tbody>
                </table>
            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        var counter = 0;
        $(document).ready(function(){
            $("#add-topic").click(function(){
                var topicId = "topic".concat(counter);
                var markup = "<tr id=" + topicId  + "> \
                                <td><input type='text' name='topics[]' class='form-control' placeholder='Topic'/> \
                                </td><td class='text-right'> \
                                <button type='button' class='btn btn-danger' onclick='deleteTopic(" + topicId +");'> \
                                    Delete \
                                </button></td> \
                              </tr>";
                $("table tbody").append(markup);
                counter++;
            });
        });

        function deleteTopic(topicId) {
                $(topicId).remove();
        } 
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stocktracker\resources\views/stocks/create.blade.php ENDPATH**/ ?>