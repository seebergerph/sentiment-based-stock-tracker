<?php $__env->startSection('content'); ?>
    <div class="stocksgrid">
        <?php if(count($data) > 0): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="link-card" href="stocks/<?php echo e($item['stock']->id); ?>">
                    <div class="card">
                        <div class="card-header bg-white">
                            <div class="d-flex justify-content-between">
                                <div><?php echo e($item['stock']->symbol); ?></div>
                                <div>$<?php echo e($item['stockInfo']['price']); ?></div>
                            </div>
                            <div class="d-flex justify-content-between">
                                <div><?php echo e($item['stockInfo']['name']); ?></div>
                                <div>($<?php echo e($item['stockInfo']['change']); ?> | <?php echo e($item['stockInfo']['changePercentage']); ?>%)</div>
                            </div>
                        </div>
                        <div class="card-body" style="margin: 0; padding: 0;">
                            <div style="padding: 20px;">
                                <div class="d-flex justify-content-between">
                                    <div>Sentiment</div>
                                    <div>Tweets</div>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <div>80.17%</div>
                                    <div>65</div>
                                </div>
                            </div>
                            <div class="progress mt-3 mb-1" style="margin-top: 14px !important; margin-left: 4px !important; margin-right: 4px !important;">
                                <div class="progress-bar bg-success" 
                                    role="progressbar" 
                                    style="width: 80.17%; height: 30px;" 
                                    aria-valuenow="80.17" 
                                    aria-valuemin="0" 
                                    aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            You have no tracked stocks
        <?php endif; ?>      
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stocktracker\resources\views/dashboard.blade.php ENDPATH**/ ?>