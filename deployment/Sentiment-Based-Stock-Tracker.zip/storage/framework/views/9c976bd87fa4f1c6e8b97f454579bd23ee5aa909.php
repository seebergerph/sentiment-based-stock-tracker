

<?php $__env->startSection('content'); ?>
    <div class="container px-5">
        <div class="d-flex justify-content-between">
        <h1 class="page-header">Sentiment Details (<?php echo e($data['stock']->symbol ?? '?'); ?>)</h1> 
            <a class="btn btn-secondary" href="/Sentiment-Based-Stock-Tracker/public/stocks/<?php echo e($data['stock']->id); ?>">
                Back
            </a>
        </div>

        <?php if(count($data) > 0): ?>
            <?php $__currentLoopData = $data['topics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-2">
                    <span class="font-weight-bold" style="font-size: 24px;"><?php echo e($item['name'] ?? '?'); ?></span>
                    <span class="ml-2" style="font-size: 14px;">(<?php echo e($item['sentiment']['countTweets'] ?? '?'); ?> Tweets)</span>
                </div>

                <div class="progress mb-3">
                    <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($item['sentiment']['averagePos'] ?? 0); ?>%;" aria-valuenow="<?php echo e($item['sentiment']['averagePos'] ?? 0); ?>" aria-valuemin="0" aria-valuemax="100">
                        <span style="font-size: 16px;"><?php echo e($item['sentiment']['averagePos'] ?? 0); ?>%</span>
                    </div>
                    <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo e($item['sentiment']['averageNeg'] ?? 0); ?>%;" aria-valuenow="<?php echo e($item['sentiment']['averageNeg'] ?? 0); ?>" aria-valuemin="0" aria-valuemax="100">
                        <span style="font-size: 16px;"><?php echo e($item['sentiment']['averageNeg'] ?? 0); ?>%</span>
                    </div>
                    <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo e($item['sentiment']['averageNeu'] ?? 0); ?>%;" aria-valuenow="<?php echo e($item['sentiment']['averageNeu'] ?? 0); ?>" aria-valuemin="0" aria-valuemax="100">
                        <span style="font-size: 16px;"><?php echo e($item['sentiment']['averageNeu'] ?? 0); ?>%</span>
                    </div>
                    <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo e($item['sentiment']['averageMix'] ?? 0); ?>%;" aria-valuenow="<?php echo e($item['sentiment']['averageMix'] ?? 0); ?>" aria-valuemin="0" aria-valuemax="100">
                        <span style="font-size: 16px;"><?php echo e($item['sentiment']['averageMix'] ?? 0); ?>%</span>
                    </div>
                </div>

                <?php if(count($item['tweets']) > 0): ?>
                <?php $__currentLoopData = $data['tweets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tweet['sentiment'] == 'POSITIVE'): ?>
                        <div class="card mt-1 border-success border-top-0 border-right-0 border-bottom-0" style="border-width: 5px !important;"> 
                            <div class="card-body">
                                <?php echo e($tweet['text']); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($tweet['sentiment'] == 'NEGATIVE'): ?>
                        <div class="card mt-1 border-danger border-top-0 border-right-0 border-bottom-0" style="border-width: 5px !important;"> 
                            <div class="card-body">
                                <?php echo e($tweet['text']); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    No tweets available.
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            You have no tracked topics for this stock
        <?php endif; ?>      

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Sentiment-Based-Stock-Tracker\resources\views/sentiment.blade.php ENDPATH**/ ?>