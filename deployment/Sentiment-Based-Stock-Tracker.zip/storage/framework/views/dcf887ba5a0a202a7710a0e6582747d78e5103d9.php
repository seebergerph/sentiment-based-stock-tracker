

<?php $__env->startSection('content'); ?>
    <div class="container px-5">
        <div class="d-flex justify-content-between">
            <h1 class="page-header"><?php echo e($data['stockInfo']['name']); ?></h1>
            <?php echo Form::open(['action' => ['StocksController@destroy', $data['stock']->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        </div>
        <h5><?php echo e($data['stock']->symbol); ?></h5>
        <div class="card">
            <div class="card-body">
                <div id="chart">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfiles'); ?>
    <script type="application/javascript" src="<?php echo e(asset('js/responsivefy.js')); ?>"></script>
    <script type="application/javascript" src="<?php echo e(asset('js/chart.js')); ?>"></script>
    <script type="application/javascript">
        margin = {top: 30, right: 70, bottom: 30, left: 30};
        width = 1000;
        height= 400;
        intraday = false;
        data = <?php echo $data['stockSeries']; ?>['values'];
        chart = new StockChart("chart", margin, width, height, intraday, data);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\stocktracker\resources\views/stocks/show.blade.php ENDPATH**/ ?>