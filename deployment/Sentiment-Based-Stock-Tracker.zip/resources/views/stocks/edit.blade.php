@extends('layouts.app')

@section('content')
<div class="container px-5">
    Edit stock
</div>
@endsection